
// Домащнее задание
// Решение квадратное уравнение
// (ax)*(ax)+bx+c=0
let a: Float = Float(readLine()!)!
let b: Float = Float(readLine()!)!
let c: Float = Float(readLine()!)!
var d: Double
d = Double((b * b) - 4 * a * c)

var x1: Double
x1 = (-b + (d*d)) / (2 * a)
var x2: Double
x2 = (-b - (d*d)) / (2 * a)
print(x1,x2)
var x3 = ("no roots")
print("no roots")


//Треугольник

let sideA: Float = Float(readLine()!)!
let sideB: Float = Float(readLine()!)!
let hypo: Float = sqrt(pow(sideA, 2) + pow(sideB, 2))
let s: Float = sideA * sideB / 2
let p: Float = sideA + sideB + hypo
print (hypo, s, p)

//Вклад

var deposit: Float = Float(readLine()!)!
let percent: Float = 15 / 100
let years: deposit; + deposit * percent * years
print("1) \(sum)")
