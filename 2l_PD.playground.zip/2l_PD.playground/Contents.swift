//import UIKit
//
// Домашнее задание
// Четное или нет число
//
//var testArray = [12, 34, 97, 45, 31, 23, 54]
//for i in testArray{
//    if i % 2 == 0 {
//        print("\(i) четное число")
//    } else {
//        print("\(i) нечетное число")
//    }
//}

// Делится ли число без остатка на 3
//var testArray = [12, 24, 6, 8]
//for i in testArray {
//    if i % 3 == 0 {
//        print("\(i) делится на 3 без остатка")
//    } else {
//        print("\(i) делится на 3 с остатком")
//    }
//}

//Возрастающий массив из ста чисел
//var Hundred: Array<Int> = []
//for i in 1...100{
//    Hundred.append(i)
//    print(Hundred)
//}

// Удалить четные и не делящиеся на 3 числа
//var hundred = 1...100
//var clearOut = hundred.filter {$0 % 2 != 0 && $0 % 3 == 0}
//print(clearOut)

// Добавляем в массив новое число Фибоначчи, и при помощи нее 50 элементов
//func fibonacci(_ n: Int) -> [Double] {
//    var fibonacci: [Double] = [1, 1]
//    (2...n).forEach{ i in
//        fibonacci.append(fibonacci[i - 1] + fibonacci[i - 2])
//    }
//    return fibonacci
//}
//print(fibonacci(50))

// Шестое задание

func simpleNumbers(arrayPassed: [Int]) -> [Int] {
    var primes: [Int] = []
    var newArr = arrayPassed
    while let newP = newArr.first {
        primes.append(newP)
        newArr = newArr.filter { $0 % newP != 0 }
    }
    return primes
}
print(simpleNumbers(arrayPassed: Array(2...100)))
